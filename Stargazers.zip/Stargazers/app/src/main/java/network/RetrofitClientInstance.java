package network;

import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;

import javax.net.SocketFactory;

import okhttp3.OkHttpClient;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class RetrofitClientInstance {

        private static Retrofit retrofit;
        private static final String BASE_URL = "https://api.github.com/";

        public static Retrofit getRetrofitInstance() {
            if (retrofit == null) {

                OkHttpClient.Builder httpClient = new OkHttpClient.Builder();

                try {
                    httpClient.sslSocketFactory(new TLSSocketFactory());

                    retrofit = new retrofit2.Retrofit.Builder()
                            .baseUrl(BASE_URL)
                            .addConverterFactory(GsonConverterFactory.create())
                            .client(httpClient.build())
                            .build();


                } catch (KeyManagementException e) {
                    e.printStackTrace();
                } catch (NoSuchAlgorithmException e) {
                    e.printStackTrace();
                }
            }
            return retrofit;
        }

}
