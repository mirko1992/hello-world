package network;

import java.util.List;

import model.Stargazer;
import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Path;

 public interface GitHubApiCalls {
        @GET("repos/{owner}/{repo}/stargazers")
        Call<List<Stargazer>> getStargazers(@Path("owner") String owner, @Path("repo") String repo);
    }


