package adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.example.stargazers.R;

import java.util.List;

import model.Stargazer;

public class StargazersAdapter extends ArrayAdapter<Stargazer> {

    public StargazersAdapter(@NonNull Context context, int resource, List<Stargazer> objects) {
        super(context, resource, objects);

    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        LayoutInflater inflater = (LayoutInflater) getContext()
                .getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        convertView = inflater.inflate(R.layout.item_view, null);

        TextView avatar = (TextView)convertView.findViewById(R.id.avatar);
        TextView userName = (TextView)convertView.findViewById(R.id.user_name);
        Stargazer stargazer = getItem(position);

        avatar.setText(stargazer.getAvatar());
        userName.setText(stargazer.getUserName());

        return convertView;


    }
}
