package model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class Stargazer {

    @SerializedName("avatar_url")
    @Expose
    private String avatar;

    @SerializedName("login")
    @Expose
    private String user_name;

    public String getAvatar() {
        return avatar;
    }

    public String getUserName() {
        return user_name;
    }
}
