package activity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;


import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.example.stargazers.R;

import java.util.List;

import adapter.StargazersAdapter;
import model.Stargazer;
import network.GitHubApiCalls;
import network.RetrofitClientInstance;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity extends AppCompatActivity {

    private EditText owner, repository;
    private Button search;
    private ListView stargazers_list;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        owner = findViewById(R.id.owner_edit_text);
        repository = findViewById(R.id.repo_edit_text);
        search = findViewById(R.id.search_button);
        stargazers_list = findViewById(R.id.list_item);


        search.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                GitHubApiCalls gitHubApiCalls = RetrofitClientInstance.getRetrofitInstance().create(GitHubApiCalls.class);
                Call<List<Stargazer>> calls = gitHubApiCalls.getStargazers(owner.getText().toString(), repository.getText().toString());
                calls.enqueue(new Callback<List<Stargazer>>() {
                    @Override
                    public void onResponse(Call<List<Stargazer>> call, Response<List<Stargazer>> response) {

                        List<Stargazer> response_list = response.body();
                        StargazersAdapter adapter = new StargazersAdapter(getApplicationContext(), R.layout.item_view, response_list);
                        stargazers_list.setAdapter(adapter);
                    }

                    @Override
                    public void onFailure(Call<List<Stargazer>> call, Throwable t) {

                    }
                });

            }
        });
    }
}
